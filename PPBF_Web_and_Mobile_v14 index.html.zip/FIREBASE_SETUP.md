# Turning on live sync for Total Assets (10 minutes, free tier)

Without this step the dashboard works, but records/documents stay on the device that added them
(the status pill says "This device only"). Steps:

1. console.firebase.google.com -> use your existing PPBF project (or create one).
2. Build -> Realtime Database -> Create database. Copy its URL (https://xxxx-default-rtdb....firebasedatabase.app).
3. Build -> Authentication -> Sign-in method -> enable Email/Password.
   Users tab -> Add user: email `admin@ppbf.org`, a strong password (this is the "cloud save password").
   Settings -> User actions -> UNTICK "Enable create (sign-up)" so nobody else can create accounts.
4. Realtime Database -> Rules -> paste the contents of `database.rules.json` -> Publish.
   Only the signed-in admin@ppbf.org can write. Everyone can read (same as the rest of the site).
   To make everything private, change the three `".read": true` to `"auth != null"` (viewers must then sign in).
5. Project settings -> General -> Web API key. In BOTH `PPBF_Web.html` and `PPBF_Mobile.html` find `const SYNC={url:'',apiKey:''` and fill:
   `url:'https://xxxx-default-rtdb....firebasedatabase.app'`, `apiKey:'AIza...'`.
6. Open the site, switch to Edit, upload something. The pill turns green: "Live · synced on all devices".

Notes
- Files are stored in the Realtime Database (max 6 MB each; photos are auto-compressed). Free tier = 1 GB total.
- Upload queue is kept on the device: if offline, changes show "pending" and upload when back online.
- Export Backup / Reset in the Admin panel do not include Total Assets records or documents.

## New in this version
- **Real-time updates**: devices now listen to the database and refresh within about a second of any save (the 12 s check stays as a fallback). Once an admin has entered the cloud password in a session, later edits auto-save ~2.5 s after the last change.
- **Excel upload**: Edit mode -> "Upload Excel" (or Assets -> year -> "Upload Excel for <year>", or Admin -> Excel upload). Accepts .xlsx / .csv, one file per year or one sheet per year. Shows a preview, then applies and syncs. "Undo" reverts the latest upload.
- **Membership status** (Active / Withdrawal / Membership Cancellation) on Profile, Form, Statement pages and in Admin -> Members. Withdrawn/cancelled members move to Members -> "Former members" (full record kept, exportable to Excel) and a blank form is generated for the same serial(s).
- No database-rule change is needed: only admin@ppbf.org can write, everyone can read.

## Total Assets Summary (new)
Assets -> "Total Assets Summary · Dashboard & A4 report" (address: #/assets/overview).
- Dashboard: deposits, deposit statement (bank ledger), expenditure statement, profit sharing (summary, investments, member-wise), other income & expenses, charts.
- A4 report: ~11 pages, print or "Save as PDF" (set margins to None / paper A4 if your browser asks). Excel export included.
- Everything is calculated live from the same data that is synced to the cloud, so it updates on every device automatically. No extra database setup or rule change is needed.

## v4 additions
- **Total Assets statement** (Assets -> Total Assets Summary): Deposit statement, Expenditure statement and Cash balance taken from the Excel "Total Assets" sheet (data as of 1 Nov 2026). Member deposits, fines, investment receipts/disbursements and expenditure are live-linked to the rest of the app; office rent, profit-share receipts and other expenditure lines are editable in Edit mode (+ buttons). Included in the A4 report and the Excel export.
- **Excel snapshot** applied once per data set on load (2026 payments through Nov, expected 11,000, fines, Investment 20 installment, Investment 25 details, Oct-2026 report). It only changes values still equal to the old snapshot, so later edits are never overwritten. Open in Edit mode and press Save once to publish it to the cloud.
- **Member Form**: "Change Photo" / "Remove" under both the Member photo and Nominee photo (Edit mode only, hidden on print). Photos are stored with the other photos and sync like them.
- Cloud sync still needs `SYNC.url` and `SYNC.apiKey` filled in (steps above); without them data stays on each device.

## v5: automatic save and real-time sync (no Save button)
- Every edit is stored on the device instantly and pushed to the cloud about 1 second later. The small pill at the bottom-left shows **Saving… / Syncing… / Saved · synced / Offline**. Tap it to sync now.
- First edit of a session asks for the cloud password once (tick "Keep me signed in on this device" to skip it next time on trusted devices). Only admin@ppbf.org can write; this is unchanged.
- Other devices update without refreshing (live stream plus a 12 s fallback check). Open forms are not interrupted while someone is typing; they refresh when the field is left.
- Offline: edits stay on the device (also after closing the page) and upload automatically when the connection returns, with retries.
- Conflicts: changes are merged field by field against the last synced copy, and version claiming is atomic, so two people editing different fields never overwrite each other. If two people change the very same field at the same moment, the later save wins. If a merge is ever impossible you are asked to load the latest or overwrite.
- Still required for any of this to work across devices: fill `SYNC.url` and `SYNC.apiKey` in both HTML files (steps 1-5 above). Total Assets records and documents (Assets > Total Assets module) keep their own existing live sync.

## v6: save / sync notifications
A small toast appears for 2 seconds (bottom-right on desktop, bottom-centre on phones) only after an operation has finished successfully: "Data Saved Successfully!" (your edits reached the database, or this device when cloud sync is not set up), "Data Synchronized Successfully!" (updates from another device arrived), "Changes Updated Successfully!" (your edits were merged with another user's). Nothing is shown while saving is in progress, during rapid typing, or for view-only preference changes; failures keep using the status pill. Hidden when printing.

## v9: new design, Web and Mobile editions
- `PPBF_Web.html`: full-width desktop layout (also adapts to tablets and phones).
- `PPBF_Mobile.html`: phone layout at any screen size (centred single column, swipeable icon tabs).
- Both have all pages visible in an icon navigation bar at the top. Data, sync, Excel, print and report logic are unchanged. Fill `SYNC.url` and `SYNC.apiKey` in both files.

## v10
- `PPBF_Mobile.html`: the icon navigation now sits in a fixed bottom bar (swipe to see all pages; the current page is highlighted). `PPBF_Web.html` keeps the top navigation.

## v11: sign-in, registration and roles (RBAC)
- Super Admin: `ppbf2023@gmail.com`. First sign-in uses the CURRENT Administrator password; then change it (account menu -> Change password).
- Anyone can Register (Member = view access). A Member can request Admin eligibility; only the Super Admin approves/rejects, assigns Admin, edits per-page permissions, deactivates/activates, removes Admin, and sees the activity log (Admin Panel -> Access control).
- Admins edit only the pages they are granted; the shared-password and access-control sections are hidden from them.
- Accounts and roles are stored on the device (localStorage), like the rest of the data before cloud sync. This enforces roles in the app only. For server-side enforcement, deploy `database.rules.json` (new role rules; legacy admin@ppbf.org kept so current sync keeps working) and move accounts to Firebase Authentication.

## v12: Investments redesign
- Investments page has four tabs: At a Glance (dashboard cards, status donut, total-vs-received chart), Investment Summary (layout of the workbook "Investment Summary" sheet, with totals row), Investment Statement (add new investment), History (log of adds, edits, deletes).
- Everything is calculated live from the same investment records used by member statements, reports and the Admin panel, and saved/synced by the existing automatic save. Edit, delete (with confirmation) and the Investment Statement form need an Admin with the Investments permission (or the Super Admin). Duplicate IDs and repeated entries (same receiver, date, amount) are blocked.
- New fields: Pending status, Actual profit/loss (blank = expected return is used).
